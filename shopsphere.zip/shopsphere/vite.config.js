import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    target: 'es2018',
    minify: 'esbuild',          // minified JS
    cssMinify: true,            // minified CSS
    sourcemap: false,
    assetsInlineLimit: 4096,    // inline tiny assets
    rollupOptions: {
      output: {
        // Split vendor code so it caches independently of app code
        manualChunks: {
          react: ['react', 'react-dom'],
          router: ['react-router-dom'],
        },
      },
    },
  },
  preview: { allowedHosts: true },
});
