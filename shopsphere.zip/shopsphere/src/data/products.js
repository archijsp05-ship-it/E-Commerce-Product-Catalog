const base = [
  { name: 'Aero Wireless Headphones', category: 'Electronics', price: 129.99, rating: 4.6, desc: 'Over-ear Bluetooth headphones with active noise cancelling and 40-hour battery life.' },
  { name: 'Pulse Smart Watch', category: 'Electronics', price: 199.0, rating: 4.4, desc: 'Fitness tracking, heart-rate monitoring, GPS and a bright AMOLED display.' },
  { name: 'Nimbus Mechanical Keyboard', category: 'Electronics', price: 89.5, rating: 4.7, desc: 'Hot-swappable tactile switches, RGB backlight and a compact 75% layout.' },
  { name: 'Lumen Desk Lamp', category: 'Home', price: 45.0, rating: 4.3, desc: 'Dimmable LED lamp with adjustable colour temperature and USB charging port.' },
  { name: 'Terra Ceramic Mug Set', category: 'Home', price: 28.0, rating: 4.5, desc: 'Set of four handmade stoneware mugs, dishwasher and microwave safe.' },
  { name: 'Cloud Memory Foam Pillow', category: 'Home', price: 39.99, rating: 4.2, desc: 'Ergonomic pillow that adapts to your sleeping position for better rest.' },
  { name: 'Trail Running Shoes', category: 'Fashion', price: 74.99, rating: 4.4, desc: 'Lightweight, breathable shoes with grippy outsoles for any terrain.' },
  { name: 'Urban Canvas Backpack', category: 'Fashion', price: 54.0, rating: 4.6, desc: 'Water-resistant 24L backpack with padded laptop sleeve and hidden pocket.' },
  { name: 'Classic Denim Jacket', category: 'Fashion', price: 69.0, rating: 4.1, desc: 'Timeless fit in durable washed denim with a soft cotton lining.' },
  { name: 'Zen Yoga Mat', category: 'Sports', price: 32.0, rating: 4.5, desc: 'Non-slip 6mm mat with alignment guides, includes a carry strap.' },
  { name: 'Peak Insulated Bottle', category: 'Sports', price: 24.5, rating: 4.8, desc: 'Double-wall steel bottle keeps drinks cold for 24h or hot for 12h.' },
  { name: 'Flex Resistance Bands', category: 'Sports', price: 19.99, rating: 4.3, desc: 'Five-level band set with handles, door anchor and a travel pouch.' },
];

export const products = base.map((p, i) => ({
  id: i + 1,
  ...p,
  // picsum seeds give a stable image per product; sized small for fast loading
  image: `https://picsum.photos/seed/shopsphere-${i + 1}/480/360`,
  imageLarge: `https://picsum.photos/seed/shopsphere-${i + 1}/960/720`,
}));

export const categories = ['All', ...new Set(base.map((p) => p.category))];

export const formatPrice = (n) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n);
