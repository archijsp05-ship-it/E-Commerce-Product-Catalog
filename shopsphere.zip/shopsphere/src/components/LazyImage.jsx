import { useState } from 'react';

// Native lazy loading + explicit dimensions (prevents layout shift) + fade-in
export default function LazyImage({ src, alt, width = 480, height = 360, className = '', priority = false }) {
  const [loaded, setLoaded] = useState(false);
  return (
    <div className={`img-wrap ${loaded ? 'loaded' : ''} ${className}`} style={{ aspectRatio: `${width} / ${height}` }}>
      <img
        src={src}
        alt={alt}
        width={width}
        height={height}
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
        onLoad={() => setLoaded(true)}
      />
    </div>
  );
}
