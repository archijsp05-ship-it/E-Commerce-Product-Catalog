export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <p>© {new Date().getFullYear()} ShopSphere. Built with React, Vite &amp; React Router.</p>
      </div>
    </footer>
  );
}
