import { memo } from 'react';
import { Link } from 'react-router-dom';
import LazyImage from './LazyImage.jsx';
import { useCart } from '../context/CartContext.jsx';
import { formatPrice } from '../data/products.js';

function ProductCard({ product }) {
  const { add } = useCart();
  return (
    <article className="card">
      <Link to={`/products/${product.id}`} aria-label={`View ${product.name}`}>
        <LazyImage src={product.image} alt={product.name} />
      </Link>
      <div className="card-body">
        <span className="tag">{product.category}</span>
        <h3>
          <Link to={`/products/${product.id}`}>{product.name}</Link>
        </h3>
        <p className="rating" aria-label={`Rated ${product.rating} out of 5`}>★ {product.rating}</p>
        <div className="card-footer">
          <strong>{formatPrice(product.price)}</strong>
          <button className="btn btn-small" onClick={() => add(product)}>
            Add to cart
          </button>
        </div>
      </div>
    </article>
  );
}

export default memo(ProductCard);
