import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext.jsx';
import { formatPrice } from '../data/products.js';

export default function Cart() {
  const { items, total, setQty, remove, clear } = useCart();

  if (items.length === 0) {
    return (
      <div className="center">
        <h1>Your cart is empty</h1>
        <Link to="/products" className="btn">Start shopping</Link>
      </div>
    );
  }

  return (
    <section>
      <h1 className="section-title">Your cart</h1>
      <ul className="cart-list">
        {items.map((i) => (
          <li key={i.id} className="cart-item">
            <img src={i.image} alt={i.name} width="96" height="72" loading="lazy" />
            <div className="cart-info">
              <Link to={`/products/${i.id}`}>{i.name}</Link>
              <span className="muted">{formatPrice(i.price)}</span>
            </div>
            <div className="qty">
              <button onClick={() => setQty(i.id, i.qty - 1)} aria-label="Decrease quantity">−</button>
              <span>{i.qty}</span>
              <button onClick={() => setQty(i.id, i.qty + 1)} aria-label="Increase quantity">+</button>
            </div>
            <strong>{formatPrice(i.price * i.qty)}</strong>
            <button className="link-btn" onClick={() => remove(i.id)}>Remove</button>
          </li>
        ))}
      </ul>
      <div className="cart-total">
        <button className="link-btn" onClick={clear}>Clear cart</button>
        <h2>Total: {formatPrice(total)}</h2>
        <button className="btn" onClick={() => alert('Demo store – checkout not implemented.')}>
          Checkout
        </button>
      </div>
    </section>
  );
}
