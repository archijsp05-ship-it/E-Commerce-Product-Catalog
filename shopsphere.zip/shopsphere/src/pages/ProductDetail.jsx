import { Link, useParams } from 'react-router-dom';
import LazyImage from '../components/LazyImage.jsx';
import { useCart } from '../context/CartContext.jsx';
import { products, formatPrice } from '../data/products.js';

export default function ProductDetail() {
  const { id } = useParams();
  const { add } = useCart();
  const product = products.find((p) => p.id === Number(id));

  if (!product) {
    return (
      <div className="center">
        <h1>Product not found</h1>
        <Link to="/products" className="btn">Back to products</Link>
      </div>
    );
  }

  return (
    <section className="detail">
      <LazyImage src={product.imageLarge} alt={product.name} width={960} height={720} priority />
      <div className="detail-info">
        <Link to="/products" className="muted">← All products</Link>
        <span className="tag">{product.category}</span>
        <h1>{product.name}</h1>
        <p className="rating">★ {product.rating} / 5</p>
        <p>{product.desc}</p>
        <p className="price">{formatPrice(product.price)}</p>
        <button className="btn" onClick={() => add(product)}>Add to cart</button>
      </div>
    </section>
  );
}
