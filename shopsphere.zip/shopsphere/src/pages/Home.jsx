import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard.jsx';
import { products } from '../data/products.js';

export default function Home() {
  const featured = [...products].sort((a, b) => b.rating - a.rating).slice(0, 4);
  return (
    <>
      <section className="hero">
        <h1>Everything you need, one sphere away.</h1>
        <p>Discover a curated catalog of electronics, home essentials, fashion and sports gear.</p>
        <Link to="/products" className="btn">Shop all products</Link>
      </section>

      <section>
        <h2 className="section-title">Top rated</h2>
        <div className="grid">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>
    </>
  );
}
